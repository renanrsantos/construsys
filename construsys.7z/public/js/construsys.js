var actFiltrar;
var camposFiltro;
var operadoresFiltro;
var valoresFiltro;

function getDisabled(){
    return $('#btn-incluir').prop('disabled');
}

function alteraBotao(botao, habilitado){
    if(habilitado){
        botao.removeClass('disabled');
    } else {
        botao.addClass('disabled');
    }
    botao.attr('enabled',habilitado);
}

function botaoHabilitado(botao){
    return botao.attr('enabled') === 'true' || botao.attr('enabled') === true;
}

function atualizaBotoes(){
    var selecionados=0;

    $('.chk-acao').each(function(){
        if ($(this).prop('checked') === true){
            selecionados++;
        } else {
            $('#chk-all').prop('checked',false);
        }
    });
    if(selecionados === 1){
        alteraBotao($('.btn-single'),!getDisabled());
        alteraBotao($('.btn-multi'),!getDisabled());
    } else if(selecionados > 1){
        alteraBotao($('.btn-single'),false);
        alteraBotao($('.btn-multi'),!getDisabled());
    } else {
        alteraBotao($('.btn-single'),false);
        alteraBotao($('.btn-multi'),false);
    }
}

function carregaDados(table,data = ''){
    data = (data!=='') ? '?data=true&'+data : '?data=true';
    url = $(table).attr('url')+data;
    dt = $(table).DataTable({"ajax": url});
}

function formataValorCampo(valor, tipo){
    switch(tipo){
        case 'int':
            return parseInt(valor);
        case 'float':
            return parseFloat(valor);
        case 'string':
            return valor.trim().toUpperCase();
        default:
            return valor;
    }
}

function setFiltro(table,botaoFiltrar){
    if(botaoFiltrar){
        camposFiltro = $('select[name=campo-filtro]');
        operadoresFiltro = $('select[name=operador-filtro]');
        valoresFiltro = $('input[name=valor-filtro]');
        valoresFiltro.each(function(){
            $(this).attr('valor',$(this).val());
        });
    }
    table.DataTable().draw();
}

function registroEncontrado(data){
    var result = true;
    if (camposFiltro !== undefined){
        for(var i = 1; i < camposFiltro.length; i++){
            var campoValorFiltro = $(valoresFiltro[i]);
            var valorFiltro = campoValorFiltro.attr('valor');
            if (valorFiltro !== ''){
                var campoFiltro = $(camposFiltro[i]).find(':selected');
                valorFiltro = formataValorCampo(valorFiltro,campoFiltro.attr('type'));
                var valorRegistro = formataValorCampo(data[campoFiltro.attr('data-column')],campoFiltro.attr('type'));
                var operador = $(operadoresFiltro[i]).val();
                var parcial = false;
                switch(operador){
                    case '=' :
                        parcial = valorRegistro === valorFiltro;
                        break;
                    case '<>' :
                        parcial = valorRegistro !== valorFiltro;
                        break;
                    case '%%' :
                        parcial = valorRegistro.indexOf(valorFiltro) > -1;
                        break;
                    case '%' :
                        parcial = valorRegistro.indexOf(valorFiltro) === 0;
                        break;
                    case '>' :
                        parcial = valorRegistro > valorFiltro;
                        break;
                    case '<' :
                        parcial = valorRegistro < valorFiltro;
                }
                result = result && parcial;
            }
        }
    }
    return result;
}

$.fn.dataTable.ext.errMode = function ( settings, helpPage, message ) {
    $(settings.nTable).dataTable().fnClearTable();
};

$.fn.dataTable.ext.search.push(
    function( settings, data, dataIndex ) {
        return registroEncontrado(data);
    }
);

$.extend(true, $.fn.dataTable.defaults, {
        "dom":  "<'row'<'col-sm-12'f>>" +
                "<'row'<'col-sm-12'tr>>" +
                "<'row'<'col-sm-4'<'col-sm-4'l><'col-sm-8'i>><'col-sm-8'p>>",
        "destroy" : true,
        "scrollY" : "280",
        "columnDefs" : [
            {"targets" : 0,
            "sorting" : false, 
            "width": "1%",
            "orderable": false}
        ],
        "lengthMenu" : [[10,25,50,-1],[10,25,50,"Todos"]],
        "order": [],
        "searching" : true,
        "language":{
            "sEmptyTable":      "Não há registros",
            "sInfo":            "_START_ à _END_ de _TOTAL_ registros",
            "sInfoEmpty":       "0 registros",
            "sInfoFiltered":    "(filtrado de _MAX_ registros)",
            "sInfoPostFix":     "",
            "sInfoThousands":   ".",
            "sLengthMenu":      "Exibir _MENU_",
            "sLoadingRecords":  "<i class='fa fa-circle-o-notch fa-spin fa-2x fa-fw'></i>",
            "sProcessing":      "<i class='fa fa-circle-o-notch fa-spin fa-2x fa-fw'></i>",
            "sSearch":          "Pesquisa rápida",
            "sZeroRecords":     "Registro não encontrado",
            "oPaginate": {
                "sFirst":       "<i class='fa fa-angle-double-left'></i>",
                "sPrevious":    "<i class='fa fa-angle-left'></i>",
                "sNext":        "<i class='fa fa-angle-right'></i>",
                "sLast":        "<i class='fa fa-angle-double-right'></i>"
            },
            "oAria": {
                "sSortAscending":  "",
                "sSortDescending": ""
            }
        }
    } 
);

$(document).ready(function(){
    var ctrl = false;
    var clickChk = false;
    $(document).keydown(function(event){
        ctrl = event.keyCode === 17;
    });
    $(document).keyup(function(event){
        ctrl = false; 
    }); 

    atualizaBotoes(); 
    
    $('table').on('click','.chk-acao',function(){
       atualizaBotoes();
       clickChk = true;
    });
   
    $('table').on('click','[role="row"]',function(){
        var td = $(this).children()[0];
        var check = $(td).children();
        var checked = (clickChk) ? !check.prop('checked') : check.prop('checked');
        if(!ctrl){
            $('.chk-acao').each(function(){
               $(this).prop('checked',false);
            });
        }
        check.prop('checked',!checked);
        atualizaBotoes();
        clickChk = false;
    });

    $('body').on('click','#chk-all',function(){
        var inputs, x;
        inputs = $('.chk-acao').get();
        for(x=0;x<inputs.length;x++){
            inputs[x].checked = this.checked;
        }
        atualizaBotoes();
    });
   
    $('body').on('click','#reset-filter',function(event){
        event.preventDefault();
        var form = $($(this).attr('aria-controls'));
        $(form).each(function(){
            this.reset();
        });
    });   
   
    $('body').on('click','#add-filter',function(event){
        event.preventDefault();
        var form = $($(this).attr('aria-controls'));
        $(form).append('<div class="filtro-adicional">'+$('#filtro-padrao').html()+'</div>');
    });
   
    $('body').on('click','#remove-filter',function(event){
        event.preventDefault();
        var form = $($(this).attr('aria-controls'));
        var filtros = form.children('.filtro-adicional');
        $(filtros).each(function(){
            $(this).remove();
        });
    });
   
    $('.dropdown-submenu .dropdown-toggle').on('click',function(){
        $('.dropdown-submenu .dropdown-menu').css('display','none');
        $(this).siblings().css('display','block');
        return false;
    });
 
    $('body').on('click','#btn-validacep',function(){
        var cep = document.getElementById('pencep[]').value;
        var sUrl = 'https://viacep.com.br/ws/'+cep+'/json/';
        console.log(sUrl);
        $.ajax({
            url: sUrl,
            success: function(data){
                var estados = document.getElementById('estcodigo[]');
                for(i = 0; i < estados.length; i++){
                    if(data.uf === estados.options[i].text){
                        estados.options[i].selected = true;
                        break;
                    }
                } 
                document.getElementById('pencep[]').value = data.cep;
                document.getElementById('bainome[]').value = data.bairro;
                document.getElementById('cidnome[]').value = data.localidade;
                document.getElementById('lognome[]').value = data.logradouro;
            }
        }); 
    });
    
    $('.btn-alterar').on('click', function(){
        if(botaoHabilitado($(this))){
            var form = $(this).parent().parent().parent();
            form.attr('action', form.prop('action') + '/alterar');
            form.submit();
        }
    });
    $('.btn-excluir').on('click', function(){
        if(botaoHabilitado($(this))){
            if(confirm('Deseja realmente excluir o(s) registro(s) selecionado(s)?')){
                var form = $(this).parent().parent().parent();
                form.attr('action', form.prop('action') + '/excluir');
                form.submit();
            }
        }
    });
    
    $('.chk-ativo').on('click',function(){
        $(this).attr('value',($(this).prop('checked')?1:0));
    });

    $('table').each(function(){
        var table = $(this);
        var url = table.attr('url');
        $.getJSON(url+'?columns=true',function(result){
            table.html(result.columns);
//            setFiltro(table,true);
            carregaDados(table);
        });
    });

    $('#btn-filtrar').on('click',function(){
        var table = $($(this).attr('aria-controls'));
        setFiltro(table,true);
    });
    
//    $('input[name="valor-filtro"]').on('keyup',function(){
//       $(this).removeAttr('filtrado');
//    });
//
//    $('select[name="operador-filtro"]').on('change',function(){
//        $($(this).siblings()[1]).removeAttr('filtrado');
//    });
//    
//    $('select[name="campo-filtro"]').on('change',function(){
//        $($(this).siblings()[1]).removeAttr('filtrado');
//    });
    

    $('body').on('keyup','input[type="search"]',function(){
        var sTable = $(this).attr('aria-controls');
        var table = $('#'+sTable);
        setFiltro(table,false);
    });
    
    $('.flexdatalist').on('select:flexdatalist',function(item,options){
        var props = $(this).data('visible-properties');
        props = props.slice(0,props.length);
        props.splice(props.indexOf($(this).prop("id")),1);
        for(i = 0; i <  props.length; i++){
            $('#'+props[i]).val(options[props[i]]);
            $('#'+props[i]).attr('validado',true);
        }
    });
       
    $('.flexdatalist-id').on('input',function(){
        $(this).attr('validado',false);
    });
    
    $('.flexdatalist-id').on('blur',function(){
        var idFlex = $(this).data('target');
        var flex = $(idFlex);
        var campoId = $(this).prop('id');
        var valId = $(this).val();
        if(valId !== "" && $(this).attr('validado') !== true){
            var props = $(flex).data('visible-properties');
            props = props.slice(0,props.length);
            $(flex).removeClass('flexdatalist-selected');
            $(flex).val("");
            $(idFlex+'-flexdatalist').val("");
            $(idFlex+'-flexdatalist').removeClass('flexdatalist-selected');
            $.ajax({
                url : $(flex).data('data'),
                data : campoId+"="+valId,
                success : function(data){
                    var result = data;//JSON.parse(data);
                    if(result.length > 0){
                        for(i = 0; i <  props.length; i++){
                            var prop = props[i];
                            if(prop === $(flex).prop('id')){
                                $('#'+prop+'-flexdatalist').val(result[0][prop]);
                                $('#'+prop).attr('validado',true);
                            } else {
                                $('#'+prop).val(result[0][prop]);
                                $('#'+prop).attr('validado',true);                                
                            }
                        }
                        $(idFlex+'-flexdatalist').focus();
                    } else {
                        for(i = 0; i <  props.length; i++){
                            var prop = props[i];
                            $('#'+prop).val("");
                            $('#'+campoId).focus();
                        }
                    }
                }
            });
        }
    });
});
