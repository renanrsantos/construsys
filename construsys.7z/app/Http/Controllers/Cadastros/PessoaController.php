<?php

namespace App\Http\Controllers\Cadastros;

use App\Http\Controllers\Controller;

class PessoaController extends Controller{
    //put your code here
    protected function getColumns() {
        return [
            ['name'=>'idpessoa','label'=>'Código','width'=>'10'],
            ['name'=>'pesnome','label'=>'Nome','width'=>'40'],
            ['name'=>'pescpfcnpj','label'=>'Cpf / Cnpj','width'=>'20'],                    
        ];
    }

    protected function getFilters() {
        return [];
    }

}
