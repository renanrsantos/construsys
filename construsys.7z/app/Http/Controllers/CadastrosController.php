<?php

namespace App\Http\Controllers;

/**
 * Description of EstruturaController
 *
 * @author renan
 */
class CadastrosController extends Controller{
    
    protected function getColumns() {
        
    }

    protected function getFilters() {
        
    }

}
