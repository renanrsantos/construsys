<?php

namespace App\Http\Models\Estrutura;

use App\Http\Models\Model;
use App\Http\Models\Cadastros\Entidade;

class Moduloinstalado extends Model
{
    protected $fillable = [
        'idmoduloinstalado', 'idmodulo', 'identidade', 'mdiativo',
    ];
       
    public function modulo(){
        return $this->belongsTo(Modulo::class,'idmodulo','idmodulo');
    }
    
    public function entidade(){
        return $this->belongsTo(Entidade::class,'identidade','identidade');
    }
    
    public function processaNovo() {
        $this->mdiativo = 1;
    }
}
