<?php

namespace App\Http\Models\Estrutura;

use App\Http\Models\Model;

/**
 * Description of Sistema
 *
 * @author renan
 */
class Subrotina extends Model{
    
    protected $fillable = [
       'idsubrotina', 'idrotina', 'sbrnome', 'sbrpath', 'sbricone'
    ];
    
    public function rotina(){
        return $this->getBelongsTo(Rotina::class,'idrotina','idrotina');
    }
         
}
