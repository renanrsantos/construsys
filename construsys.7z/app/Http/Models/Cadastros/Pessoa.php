<?php

/**
 * Description of Pessoa
 *
 * @author renan.santos
 */
namespace App\Http\Models\Cadastros;

use App\Http\Models\Model;

class Pessoa extends Model{
    
    protected $fillable = [
        'idpessoa','pestipo','pesnome','pescpfcnpj','pesrgie'
    ];
}
