@extends('layouts.app')
    @section('content')
        <p>inserir registro</p>
    @endsection
