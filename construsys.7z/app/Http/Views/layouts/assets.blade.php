<!-- Fonts -->
<link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="{{URL::asset('css/bootstrap.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('css/bootstrap-theme.min.css')}}">
<link rel="stylesheet" href="{{URL::asset('css/font-awesome.min.css')}}">
<script src="{{URL::asset('js/jquery-3.1.0.min.js')}}"></script>
<script src="{{URL::asset('js/bootstrap.min.js')}}"></script>
<script src="{{URL::asset('js/comportamento.js')}}"></script>