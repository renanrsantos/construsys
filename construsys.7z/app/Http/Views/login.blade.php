<!DOCTYPE html>

@extends('layouts.app')

    @section('main-menu')
        <!-- menu sobrescrito -->
    @endsection
    
    @section('content')    
        @include('layouts.form-login')
    @endsection
