<!DOCTYPE html>
@extends('layouts.app')

@section('content')
    <?php echo $sistema.'/'.$rotina;?>
@endsection