<?php

namespace App\Html;
use \Illuminate\Support\HtmlString;
use Illuminate\Support\Facades\Request;

class FormBuilder extends \Collective\Html\FormBuilder{
    
    /** @var \App\Html\HtmlBuilder */
    protected $html;
    
protected function formatSizeInput($size){
        switch($size){
            case 'xs':
                return 'col-md-1';
            case 'sm':
                return 'col-md-2';
            case 'sm1':
                return 'col-md-3';
            case 'md':
                return 'col-md-4';
            case 'md1':
                return 'col-md-5';
            case 'md2':
                return 'col-md-6';
            case 'lg':
                return 'col-md-8';
            case 'lg1':
                return 'col-md-10';
            case 'xl':
                return 'col-md-12';
            default :
                return 'col-md-12';
        }
    }
    
    public function input($type, $name, $value = null, $options = array()) {
        $label = '';
        $input = parent::input($type, $name, $value, $options);
        if(!in_array($type, ['checkbox','hidden','button'])){
            $this->html->addClassAttributes($options,'form-control input-sm');
            if(!isset($options['label'])){
                $options['label'] = $this->html->nbsp();
            }
            if($options['label'] != ''){
                $label = $this->label($name,$options['label'],['class'=>'col-md-3 control-label']);
            }
            if(!isset($options['size'])){
                $options['size'] = 'lg';
            }
            $input = $this->html->tag('div',parent::input($type, $name, $value, $options),['class'=>$this->formatSizeInput($options['size'])]);
        }
        
        return $this->toHtmlString($label . $input);
    }
    
    public function open(array $options = array()) {
        return $this->toHtmlString(parent::open($options) . $this->hidden('redirect',Request::url()));
    }
    
    public function text($name, $value = null, $options = array()) {
        return parent::text($name, $value, $options);
    }
    
    public function password($name, $value = null, $options = array()){
        return parent::password($name,$value,$options);
    }
    
    public function checkbox($name, $value = 1, $checked = null, $options = []){
        $label = '';
        if(isset($options['label'])){
            $label = $this->html->tag('strong',$options['label']);
            unset($options['label']);
        }
        $checkbox = parent::checkbox($name, $value, $checked, $options);
        if($label){
            $checkbox = $this->html->tag('label',$checkbox . ' ' . $label);
        }
        return $this->html->tag('div',$checkbox/*,['class'=>'checkbox']*/);
    }

    public function checkboxSimple($name, $value = 1, $checked = null, $options = []){
        return parent::checkbox($name,$value,$checked,$options);
    }
    
    public function button($value = null, $options = array()) {
        if(isset($options['icon'])){
            $value = $this->html->icon($options['icon']) . $value;
            unset($options['icon']);
        }
        if(!isset($options['color'])){
            $options['color'] = 'secondary';
        }
        $this->html->addClassAttributes($options, 'btn btn-'.$options['color']);
        unset($options['color']);
        return parent::button($value, $options);
    }

    public function formGroup($elements = array(), $attributes = array(), $row = true){
        if(count($elements) == 0){
            return '';
        }
        $html = '';
        foreach($elements as $element){
            $html .= ($element instanceof HtmlString) ? $element->toHtml() : $element;
        }
        $classRow = ($row) ? ' row' : '';
        $this->html->addClassAttributes($attributes,'form-group' . $classRow);
        return $this->html->tag('div', $html, $attributes);
    }
    
    public function select($name, $list = array(), $selected = null, $options = array()) {
        $this->html->addClassAttributes($options, 'form-control');
        return parent::select($name, $list, $selected, $options);
    }
    
    public function getSelectOption($display, $value, $selected) {
        return $this->html->tag('option', $display['label'],$display);
    }
    
    public function getOperadoresFiltro(){
        $operadores[] = ['value'=>'=','label'=>'Igual'];
        $operadores[] = ['value'=>'<>','label'=>'Diferente'];
        $operadores[] = ['value'=>'%%','label'=>'Contém'];
        return $operadores;
    }
    
    public function tableFilter($filters,$table){
        $pattern = $this->formGroup([
            $this->select('campo-filtro',$filters,null,['class'=>'input-sm','style'=>'width:100px;']),
            $this->select('operador-filtro',$this->getOperadoresFiltro(),null,['class'=>'input-sm','style'=>'width:100px;']),
            $this->html->tag('input','',['placeholder'=>'Pesquisar...','name'=>'valor-filtro','class'=>'form-control input-sm','style'=>'width:200px;'])
        ],[],false);
        $return[] = $this->html->tag('div',$this->html->tag('div',$pattern,['class'=>'row']),['class'=>'sr-only','id'=>'filtro-padrao']);
        $return[] = '<form class="form-inline" id="filtro-'.$table.'">';
        $return[] = $this->formGroup([
            $pattern,
            $this->splitButton(['Filtrar',['id'=>'btn-filtrar','aria-controls'=>$table]],
                    [[$this->html->icon('fa fa-plus').'Adicionar Filtro',['id'=>'add-filter','aria-controls'=>'#filtro-'.$table]],
                     [$this->html->icon('fa fa-close').'Remover Filtros',['id'=>'remove-filter','aria-controls'=>'#filtro-'.$table]],
                     [$this->html->icon('fa fa-refresh').'Limpar Filtros',['id'=>'reset-filter','aria-controls'=>'#filtro-'.$table]]],'info')
        ]);
        $return[] = '</form>';
        return $this->toHtmlString(implode('', $return));
    }
       
    public function splitButton(array $button, array $elements, string $color = 'primary'){
        $this->html->addClassAttributes($button[1], 'btn-'.$color.' btn-sm');
        $attributes = array_merge($button[1],['icon'=>'fa fa-search']);
        $btn = $this->button($button[0],$attributes);
        $this->html->addClassAttributes($button[1], 'dropdown-toggle');
        $attributes = array_merge($button[1],['data-toggle'=>'dropdown','aria-haspopup'=>'true','aria-expanded'=>'false']);
        $attributes['id'] = '';
        $split = $this->button($this->html->tag('span','',['class'=>'caret']),$attributes);
        foreach($elements as $element){
            $this->html->addClassAttributes($element[1], 'dropdown-item');
            $list[] = $this->html->tag('a',$element[0],$element[1])->toHtml();
        }
        $elements = $this->html->ul($list,['class'=>'dropdown-menu']);
        $content = $btn . $split . $elements;
        return $this->html->tag('div',$content,['class'=>'btn-group']);
    }
    
    private function formataCamposInputConsulta($campos){
        $campos = explode(',', $campos);
        $retorno = [];
        foreach($campos as $campo){
            $retorno[] = '"'.$campo.'"';
        }
        return implode(',', $retorno);
    }
    
    public function inputConsulta(string $modulo, string $rotina, array $attributes){
        $model = app()->make('\\App\\Http\\Models\\'. ucfirst($modulo).'\\'.ucfirst($rotina));
        $visible = $this->formataCamposInputConsulta($model->consulta['visible']);
        $search = $this->formataCamposInputConsulta($model->consulta['search']);
        $text = $model->consulta['text'];
        $label = $model->consulta['label'];
        $url = Request::segment(1).'/modulo/'.$modulo.'/rotina/'.$rotina.'/data?datalist=true&campos='.$model->consulta['visible'];//.'&_token='.csrf_token();
        $attributes = array_merge($attributes,['data-data'=> url($url), 
                            'data-selection-required'=>'true',
                            'data-focus-first-result'=>'true',
                            'data-min-length'=>'2',
                            'data-search-contain'=>'true',
                            'data-search-in'=>'['.$search.']',
                            'data-visible-properties'=>'['.$visible.']',
                            'data-text-property'=>'{'.$text.'}',
                            'data-request-type'=>'get',
                            'value'=>'',
                            'value-id'=>'',
                            'size'=>'md',
                            'label'=>'',
                            'id'=>$text,
                            'placeholder'=>'Digite para pesquisar',
                            'class'=>'flexdatalist']);
        $attributesId = ['class'=>'flexdatalist-id','label'=>$label,'size'=>'xs','data-target'=>'#'.$text];
        $inputId = $this->input('text',$model->getKeyName(),$attributes['value-id'],$attributesId);
        $inputText = $this->input('text', $text, $attributes['value'],$attributes);
        return $this->toHtmlString($inputId.$inputText);
    }    

}
