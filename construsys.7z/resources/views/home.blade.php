@extends('layouts.app')

@section('content')
    {{Html::listGroup($errors->all(),'danger')}}
@endsection

