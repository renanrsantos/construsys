<a class="btn btn-primary" onclick="history.go(-1)">Cancelar</a>
<button class="btn btn-primary" type="reset">Limpar</button>
<button class="btn btn-primary" type="submit">Confirmar</button>