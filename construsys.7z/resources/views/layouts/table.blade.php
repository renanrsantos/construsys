<?php
    $table = Request::segment(3).'-'.Request::segment(5);
?>
@extends('layouts.app')

@section('content')
<div class="row">
    {{Form::tableFilter($filters,$table)}}
</div>
&nbsp;
<div class="row">
    {{Form::open(array('url'=>Request::url(),'class'=>'form-horizontal','id'=>'form-registros'))}}
        <div class="form-group">
            <div class="btn-group btn-group-sm">
                <a href="{{url(Request::url().'/novo')}}" class="btn btn-primary"><i class="fa fa-plus" id="btn-incluir">&nbsp;</i> Inserir</a>
                <button type="button" class="btn btn-primary btn-alterar btn-single"><i class="fa fa-pencil">&nbsp;</i> Alterar</button>
                <button type="button" class="btn btn-primary btn-excluir btn-multi"><i class="fa fa-trash">&nbsp;</i> Excluir</button>
                <button type="button" class="btn btn-primary btn-visualizar btn-single"><i class="fa fa-eye">&nbsp;</i> Visualizar</button>
            </div> 
            <div class="btn-group btn-group-sm">
                @foreach($btns as $btn)
                    <{{$btn['type']}} type="button" 
                        href="{{$btn['url']}}" 
                        class="btn btn-primary btn-extra {{$btn['type']}}">
                        <i class="fa fa-{{$btn['icon']}}">&nbsp;</i> 
                        {{$btn['label']}}
                    </{{$btn['type']}}>
                @endforeach
            </div>
        </div>
        <div class="form-group">
            <table id="{{$table}}" class="table table-bordered table-striped table-hover table-condensed" url="{{Request::url()}}/data"></table>
        </div>
    {{Form::close()}}
</div>
@overwrite


