@extends('layouts.app')

@section('content')
    {{Form::open(array('url'=>Request::url(),'class'=>'form-horizontal col-md-4'))}}
    {{Form::formGroup([
        Form::text('idmodulo',$record->idmodulo,['label'=>'Código','required','readonly'])
      ])
    }}
    {{Form::formGroup([
        Form::text('modnome',$record->modnome,['label'=>'Nome','required'])
      ])
    }}
    {{Form::formGroup([
        Form::text('modpath',$record->modpath,['label'=>'Path','required'])
      ])
    }}
    {{Form::formGroup([
        Form::text('modicone',$record->modicone,['label'=>'Ícone'])
      ])
    }}
    @include('layouts.buttons-form')
    {{Form::close()}}
@endsection