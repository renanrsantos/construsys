@extends('layouts.app')
@section('content')
    {{Form::open(array('url'=>Request::url(),'class'=>'form-horizontal'))}}
    {{Form::formGroup([
        Form::inputConsulta('estrutura','modulo',['required',
            'value-id'=>$record->modulo ? $record->modulo->idmodulo : '',
            'value'=>$record->modulo ? $record->modulo->modnome : ''])
    ])}}
    {{Form::formGroup([
        Form::text('idrotina',$record->idrotina,['required','readonly','label'=>'Rotina','size'=>'xs']),
        Form::text('rotnome',$record->rotnome,['required','label'=>'','size'=>'md'])
    ])}}
    {{Form::formGroup([
        Form::text('rotpath',$record->rotpath,['required','label'=>'Path','size'=>'md1'])
    ])}}
    {{Form::formGroup([
    Form::text('roticone',$record->roticone,['label'=>'Ícone','size'=>'md1'])        
    ])}}
    @include('layouts.buttons-form')
    {{Form::close()}}
@endsection