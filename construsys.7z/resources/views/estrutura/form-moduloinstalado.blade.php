@extends('layouts.app')

@section('content')
    {{Form::open(array('url'=>Request::url(),'class'=>'form-horizontal'))}}
    {{Form::formGroup([
        Form::text('idmoduloinstalado',$record->idmoduloinstalado,['required','readonly','label'=>'Id'])
    ])}}
    {{Form::formGroup([
        Form::text('identidade',$entidadeSelecionada->identidade,['required','readonly','label'=>'Cod. Empresa']),
        Form::text('pesnome',$entidadeSelecionada->pessoa->pesnome,['required','readonly','label'=>'Empresa'])        
    ])}}
    {{Form::formGroup([
        Form::text('idmodulo',$record->idmodulo,['required',($record->idmodulo)?'readonly':'','label'=>'Cod. Módulo']),
        Form::text('modnome',$record->idmodulo ? $record->modulo->modnome : '',[($record->idmodulo)?'readonly':'','label'=>'Módulo']),
        Form::checkbox('mdiativo',$record->mdiativo,$record->mdiativo,['class'=>'chk-ativo','label'=>'Ativo'])
    ])}}
    @include('layouts.buttons-form')
    {{Form::close()}}
@endsection