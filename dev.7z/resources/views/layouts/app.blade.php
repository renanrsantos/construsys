<!DOCTYPE html>
<html>
    <head>
        <title>{{config('app.cliente')}}</title>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        @include('layouts.assets')
        <?php $auth = Auth::check();?>
    </head>
    <body>
        @section('main-menu')
            @if ($auth)
                @include('layouts.menus.menu-sistema')
            @endif
        @show
        <div class="container-fluid">
            {{Html::listGroup($errors->all(),'danger')}}
            @if (!$auth && Request::url() != 'login')
                @include('layouts.form-login')
            @else
                @yield('content')
            @endif
        </div>
        @if($auth)
            @include('layouts.footer')
        @endif
    </body>
</html>
