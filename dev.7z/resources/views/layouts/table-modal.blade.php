@extends('layouts.modal')

@section('header')
	{{$titulo}}
@endsection

@section('body')
	@include('layouts.table')
@endsection

@section('footer')

@overwrite