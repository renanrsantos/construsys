<div class="pull-right">
<button class="btn btn-primary btn-sm" type="button" tabindex='-1' data-dismiss="modal"><i class="fa fa-close">&nbsp;</i> Cancelar</button>
<button class="btn btn-primary btn-sm" type="reset" tabindex='-1'><i class="fa fa-refresh">&nbsp;</i> Limpar</button>
<button class="btn btn-primary btn-sm" type="button" data-target="#{{$table}}" data-toggle="submit"><i class="fa fa-save">&nbsp;</i> Confirmar</button>
</div>