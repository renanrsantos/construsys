<?php

namespace App\Http\Controllers\Cadastros;

use App\Http\Controllers\Controller;
// use App\Http\Models\Cadastros\Pessoa;
// use App\Http\Models\Cadastros\Pessoacontato;
// use App\Http\Models\Cadastros\Pessoaendereco;

class ClienteController extends Controller{
	protected function getColumns(){
		return [];
	}

	protected function getFilters(){
		return [];
	}

	protected function getTitulo(){
		return '';
	}
}
