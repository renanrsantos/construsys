<?php

namespace App\Http\Controllers\Modulos;
use App\Http\Controllers\Controller;

/**
 * Description of EstruturaController
 *
 * @author renan
 */
class CadastrosController extends Controller{
    
    protected function getColumns() {
        
    }

    protected function getFilters() {
        
    }
    
    protected function getTitulo() {
        return 'Cadastros';
    }

}
