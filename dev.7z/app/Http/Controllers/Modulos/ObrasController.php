<?php

namespace App\Http\Controllers\Modulos;
use App\Http\Controllers\Controller;

/**
 * Description of ObrasController
 *
 * @author renan
 */
class ObrasController extends Controller{
    
    protected function getColumns() {
        
    }

    protected function getFilters() {
        
    }

    protected function getTitulo() {
        return 'Obras';
    }
}
