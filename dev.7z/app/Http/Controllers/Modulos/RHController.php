<?php

namespace App\Http\Controllers\Modulos;
use App\Http\Controllers\Controller;

/**
 * Description of RHController
 *
 * @author renan
 */
class RHController extends Controller{
    
    protected function getColumns() {
        
    }

    protected function getFilters() {
        
    }
    
    protected function getTitulo() {
        return 'Recursos Humanos';
    }

}
