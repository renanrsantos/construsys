<?php

/**
 * Description of Categoriaproduto
 *
 * @author renan.santos
 */
namespace App\Http\Models\Cadastros;

use App\Http\Models\Model;

class Categoriaproduto extends Model{

    protected $fillable = [
        'idcategoriaproduto','catdescricao',
    ];
    
}
